


void initialise_queue () {
  for (int i = 0; i < NUM_JUNCTIONS; i++) {
    for (int j = 0; j < NUM_SIGNALS; j++) {
      q[i].push (j);
    }
  }
}

int get_car_count_from_segment (int segmentno) {
  int cnt = 0;
  if (segmentno == INVALID_SEGMENT) {
    return 0;
  }
  for (int i = 29; i > 0; i--) {
    if (segment[segmentno][i] > 0) {
      cnt++;
    }
  }
  return cnt;
}

int check_priority (int num_cars[]) {
  int index = 0;
  for (int i = 1; i < NUM_SIGNALS; i++) {
    if (num_cars[index] < num_cars[i]) {
      index = i;
    }
  }
  return index;
}

void scheduler (int jun[], int priority, int pri[], int first, int num_cars[]) {

  if (q[first].empty ()) {
    initialise_queue ();
    scheduler (jun, priority, pri, first, num_cars);
    return;
  }

  int new_light = q[first].front ();
  q[first].pop ();

  if (priority == 0) {
    //at first junction, always allow cars from node A if no other car is returning back to A
    if (first == 0) {
      jun[1] = 2; //change light to green for the signal which faces A
      q[first].push (new_light);
      return;
    }

    //simple round robin
    if (jun[new_light] != 0) {
      jun[new_light] = 2; //set to green
      q[first].push (new_light);
      return;
    } else {
      q[first].push (new_light);
      scheduler (jun, priority, pri, first, num_cars);
      return;
    }

  } else {
    int high_pri = check_priority (num_cars);;
    //if priority = 1 and light is off, change the priority to 0
    if (jun[new_light] == 0) {
      q[first].push (new_light);
      scheduler (jun, priority, pri, first, num_cars);
      return;
    } else if (jun[new_light] != 0 && new_light == high_pri) {
      //set to green for the signal with priority = max_cars
      jun[new_light] = 2;
      q[first].push (new_light);
      return;
    } else {
      q[first].push (new_light);
      scheduler (jun, priority, pri, first, num_cars);
      return;
    }
  }
}

void controller (int time) {
  for (int i = 0; i < NUM_JUNCTIONS; i++) {
    int priority = 0;
    int num_cars[NUM_SIGNALS] = {0};
    for (int j = 0; j < NUM_SIGNALS; j++) {
      if (il[i][j] == 2) {
        il[i][j] = 1; //change the green signals to red
      }
      if (p_light[i][j] >= 1) {
        priority = 1;
        int segmentno = segment_info[i][j];
        num_cars[j] = get_car_count_from_segment (segmentno);
      }
    }
    //std::cout<<"priority"<<priority<<'\n';
    scheduler (il[i], priority, p_light[i], i, num_cars);
  }
  
  std::cout << "lights at time t = " << time << "\n";
  for (int i = 0; i < NUM_JUNCTIONS; i++) {
    
    //std::cout << "intersection = " << i << "\n";
    for (int j = 0; j < NUM_SIGNALS; j++) {
      std::cout << il[i][j] << " ";
    }
    std::cout << "\n";
  }
  
}





